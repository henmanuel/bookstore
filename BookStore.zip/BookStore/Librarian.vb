﻿Public Class Librarian
    Inherits User

    Public Sub New(username As String, password As String)
        MyBase.New(username, password)
    End Sub

    ' Métodos específicos del bibliotecario aquí
End Class